﻿using System.Data.SqlClient;
using LibConexionBD;


namespace LIB_logicaN_cliente
{
    public class Cls_NegocioCliente
    {
        #region atributos
        private int idCliente;
        private string nombreCliente;
        private string apellidoCliente;
        private string emailCliente;
        private string telefonoCliente;
        private SqlDataReader objReader;
        private string error;
        #endregion



        #region propiedades
        public int gsIdCliente { get => idCliente; set => idCliente = value; }
        public string gsNombreCliente { get => nombreCliente; set => nombreCliente = value; }
        public string gsApellidoCliente { get => apellidoCliente; set => apellidoCliente = value; }
        public string gsEmailCliente { get => emailCliente; set => emailCliente = value; }
        public string gsTelefonoCliente { get => telefonoCliente; set => telefonoCliente = value; }
        public SqlDataReader gsObjReader { get => objReader; set => objReader = value; }
        public string gsError { get => error; set => error = value; }
        #endregion
        #region metodos

        public Cls_NegocioCliente()
        {
            idCliente = 0;
            nombreCliente = "";
            apellidoCliente = "";
            emailCliente = "";
            telefonoCliente = "";
            error = "";
        }

        public bool consultarClienteId()
        {
            string sentencia = "EXECUTE PA_listarClienteById " + idCliente + "";
            ClsConexion objCnn = new ClsConexion();
            if (!objCnn.Consultar(sentencia, false))
            {
                error = objCnn.Error;
                objCnn = null;
                return  false;
            }

            else
            {
                objReader = objCnn.Reader;
                objCnn = null;
                return true;
            }
            
        }

        public bool registrarCliente()
        {
            string sentencia = "EXECUTE PA_GUARDARCLIENTE "+idCliente+", "+nombreCliente+" , '"+apellidoCliente+"' , '"+emailCliente+"' , '"+telefonoCliente+"'";
            ClsConexion objCnn = new ClsConexion();
            if(!objCnn.EjecutarSentencia(sentencia, false))
            {
                error = objCnn.Error;
                objCnn = null;
                return false;
            }
            else
            {
                objCnn = null;
                return  true;
            }
        }

        public bool actualizarCliente()
        {
            string sentencia = "EXECUTE PA_ACTUALIZARCLIENTE " + idCliente + ", " + nombreCliente + " , '" + apellidoCliente + "' , '" + emailCliente + "' , '" + telefonoCliente + "'";
            ClsConexion objCnn = new ClsConexion();
            if (!objCnn.EjecutarSentencia(sentencia, false))
            {
                error = objCnn.Error;
                objCnn = null;
                return false;
            }
            else
            {
                objCnn = null;
                return true;
            }
        }

        public bool eliminarCliente()
        {
            string sentencia = "EXECUTE PA_ELIMINARCLIENTE " + idCliente + "";
            ClsConexion objCnn = new ClsConexion();
            if (!objCnn.EjecutarSentencia(sentencia, false))
            {
                error = objCnn.Error;
                objCnn = null;
                return false;
            }
            else
            {
                objCnn = null;
                return true;
            }
        }




        #endregion
    }
}

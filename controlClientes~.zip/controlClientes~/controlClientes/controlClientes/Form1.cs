﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;
using LIB_logicaN_cliente;

namespace controlClientes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_buscarCli_Click(object sender, EventArgs e)
        {
            if (buscarCliente())
            {
                btn_eliminar.Enabled = true;
            }
            else
            {
                btn_eliminar.Enabled = false;
            }
        }

        private bool buscarCliente()
        {
            Cls_NegocioCliente objNCliente = new Cls_NegocioCliente();
            

            if (txt_idCliente.Text=="")    
            {
                MessageBox.Show("El campo id cliente esta vacio, por favor escriba un valor para continuar");
                
            }
            else
            {
                objNCliente.gsIdCliente = Convert.ToInt32(txt_idCliente.Text);
            }

            if (!objNCliente.consultarClienteId())
            {
                MessageBox.Show(objNCliente.gsError);
                return false;
            }

            else
            {
                SqlDataReader readerCli;
                readerCli = objNCliente.gsObjReader;

                if (readerCli.HasRows)
                {
                    readerCli.Read();
                    lbl_nombreCli.Text = readerCli.GetString(0);
                    lbl_apellidoCli.Text = readerCli.GetString(1);
                    lbl_emailCli.Text = readerCli.GetString(2);
                    lbl_telefonoCli.Text = readerCli.GetString(3);
                    readerCli.Close();
                    return true; 

                }

                else
                {
                    MessageBox.Show(this, "El cliente no existe, Intente nuevamente");
                    txt_idCliente.Text = "";
                    txt_idCliente.Focus();
                    return true;
                }
            }

           
        }

        private void btn_guardar_Click(object sender, EventArgs e)
        {
            guardarCliente();
            limpiar();
        }

        private void limpiar()
        {
            txt_idCliente.Text = "";
            txt_nombreCliente.Text = "";
            txt_apellidoCliente.Text = "";
            txt_emailCliente.Text = "";
            txt_telefonoCliente.Text = "";
            lbl_nombreCli.Text = "";
            lbl_apellidoCli.Text = "";
            lbl_emailCli.Text = "";
            lbl_telefonoCli.Text = "";

        }

        private void guardarCliente()
        {
            Cls_NegocioCliente objCliente = new Cls_NegocioCliente();

            try
            {
                objCliente.gsIdCliente = Convert.ToInt32(txt_idCliente.Text);
                objCliente.gsNombreCliente = txt_nombreCliente.Text;
                objCliente.gsApellidoCliente = txt_apellidoCliente.Text;
                objCliente.gsEmailCliente = txt_emailCliente.Text;
                objCliente.gsTelefonoCliente = txt_telefonoCliente.Text;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            if (!objCliente.registrarCliente())
            {
                MessageBox.Show(objCliente.gsError);
                return;
            }
            MessageBox.Show("se guardo el cliente correctamente ");
        }

        private void btn_actualizar_Click(object sender, EventArgs e)
        {
            actualizarCliente();
            limpiar();
        }

        private void actualizarCliente()
        {
            Cls_NegocioCliente objCliente = new Cls_NegocioCliente();

            try
            {
                objCliente.gsIdCliente = Convert.ToInt32(txt_idCliente.Text);
                if (string.IsNullOrEmpty(txt_nombreCliente.Text))
                {
                    txt_nombreCliente.Text = "";
                    objCliente.gsNombreCliente = txt_nombreCliente.Text;
                }
                else
                {
                    objCliente.gsNombreCliente = txt_nombreCliente.Text;
                }
                
                if (string.IsNullOrEmpty(txt_apellidoCliente.Text))
                {
                    txt_apellidoCliente.Text = "";
                    objCliente.gsApellidoCliente = txt_apellidoCliente.Text;
                }
                else
                {
                    objCliente.gsApellidoCliente = txt_apellidoCliente.Text;
                }

                if (string.IsNullOrEmpty(txt_emailCliente.Text))
                {
                    txt_emailCliente.Text = "";
                    objCliente.gsEmailCliente = txt_emailCliente.Text;
                }
                else
                {
                    objCliente.gsEmailCliente = txt_emailCliente.Text;
                }

                if (string.IsNullOrEmpty(txt_telefonoCliente.Text))
                {
                    txt_telefonoCliente.Text = "";
                    objCliente.gsTelefonoCliente = txt_telefonoCliente.Text;
                }
                else
                {
                    objCliente.gsTelefonoCliente = txt_telefonoCliente.Text;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }

            if (!objCliente.actualizarCliente())
            {
                MessageBox.Show(objCliente.gsError);
                return;
            }
            MessageBox.Show("se actualizaron los datos correctamente");
        }

        private void btn_eliminar_Click(object sender, EventArgs e)
        {
            DialogResult resp = MessageBox.Show("Deseas eliminar el cliente", "Eliminar" , MessageBoxButtons.YesNo);
            if (resp == DialogResult.Yes) 
            {
                eliminarCliente();
                limpiar();
                btn_eliminar.Enabled = false;
            }

            else if (resp == DialogResult.No)
            {
                btn_eliminar.Enabled = false;
                limpiar();
            }

        }

        private void eliminarCliente()
        {
            Cls_NegocioCliente objCliente = new Cls_NegocioCliente();
            try
            {
                objCliente.gsIdCliente = Convert.ToInt32(txt_idCliente.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            if (!objCliente.eliminarCliente())
            {
                MessageBox.Show(objCliente.gsError);
                return;
            }
            MessageBox.Show("ATENCION! se elimino el cliente de la base de datos");
        }
    }
}

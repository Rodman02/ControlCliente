﻿
namespace controlClientes
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_idCliente = new System.Windows.Forms.TextBox();
            this.txt_nombreCliente = new System.Windows.Forms.TextBox();
            this.txt_apellidoCliente = new System.Windows.Forms.TextBox();
            this.txt_emailCliente = new System.Windows.Forms.TextBox();
            this.txt_telefonoCliente = new System.Windows.Forms.TextBox();
            this.btn_buscarCli = new System.Windows.Forms.Button();
            this.lbl_nombreCli = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lbl_apellidoCli = new System.Windows.Forms.Label();
            this.lbl_emailCli = new System.Windows.Forms.Label();
            this.lbl_telefonoCli = new System.Windows.Forms.Label();
            this.btn_guardar = new System.Windows.Forms.Button();
            this.btn_actualizar = new System.Windows.Forms.Button();
            this.btn_eliminar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Sitka Subheading", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(62, 80);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 35);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID Cliente";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Sitka Subheading", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(65, 115);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(185, 35);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nombre cliente";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Sitka Subheading", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(62, 164);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(188, 35);
            this.label3.TabIndex = 2;
            this.label3.Text = "Apellido cliente";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Sitka Subheading", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(62, 212);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(161, 35);
            this.label4.TabIndex = 3;
            this.label4.Text = "Email cliente";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Sitka Subheading", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(62, 256);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(191, 35);
            this.label5.TabIndex = 4;
            this.label5.Text = "Telefono cliente";
            // 
            // txt_idCliente
            // 
            this.txt_idCliente.Location = new System.Drawing.Point(270, 80);
            this.txt_idCliente.Name = "txt_idCliente";
            this.txt_idCliente.Size = new System.Drawing.Size(302, 22);
            this.txt_idCliente.TabIndex = 5;
            // 
            // txt_nombreCliente
            // 
            this.txt_nombreCliente.Location = new System.Drawing.Point(270, 127);
            this.txt_nombreCliente.Name = "txt_nombreCliente";
            this.txt_nombreCliente.Size = new System.Drawing.Size(302, 22);
            this.txt_nombreCliente.TabIndex = 6;
            // 
            // txt_apellidoCliente
            // 
            this.txt_apellidoCliente.Location = new System.Drawing.Point(270, 176);
            this.txt_apellidoCliente.Name = "txt_apellidoCliente";
            this.txt_apellidoCliente.Size = new System.Drawing.Size(302, 22);
            this.txt_apellidoCliente.TabIndex = 7;
            // 
            // txt_emailCliente
            // 
            this.txt_emailCliente.Location = new System.Drawing.Point(270, 224);
            this.txt_emailCliente.Name = "txt_emailCliente";
            this.txt_emailCliente.Size = new System.Drawing.Size(302, 22);
            this.txt_emailCliente.TabIndex = 8;
            // 
            // txt_telefonoCliente
            // 
            this.txt_telefonoCliente.Location = new System.Drawing.Point(270, 268);
            this.txt_telefonoCliente.Name = "txt_telefonoCliente";
            this.txt_telefonoCliente.Size = new System.Drawing.Size(302, 22);
            this.txt_telefonoCliente.TabIndex = 9;
            // 
            // btn_buscarCli
            // 
            this.btn_buscarCli.Location = new System.Drawing.Point(603, 235);
            this.btn_buscarCli.Name = "btn_buscarCli";
            this.btn_buscarCli.Size = new System.Drawing.Size(249, 55);
            this.btn_buscarCli.TabIndex = 10;
            this.btn_buscarCli.Text = "Buscar";
            this.btn_buscarCli.UseVisualStyleBackColor = true;
            this.btn_buscarCli.Click += new System.EventHandler(this.btn_buscarCli_Click);
            // 
            // lbl_nombreCli
            // 
            this.lbl_nombreCli.AutoSize = true;
            this.lbl_nombreCli.Location = new System.Drawing.Point(101, 326);
            this.lbl_nombreCli.Name = "lbl_nombreCli";
            this.lbl_nombreCli.Size = new System.Drawing.Size(0, 16);
            this.lbl_nombreCli.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(304, 256);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 16);
            this.label6.TabIndex = 12;
            // 
            // lbl_apellidoCli
            // 
            this.lbl_apellidoCli.AutoSize = true;
            this.lbl_apellidoCli.Location = new System.Drawing.Point(101, 366);
            this.lbl_apellidoCli.Name = "lbl_apellidoCli";
            this.lbl_apellidoCli.Size = new System.Drawing.Size(0, 16);
            this.lbl_apellidoCli.TabIndex = 13;
            // 
            // lbl_emailCli
            // 
            this.lbl_emailCli.AutoSize = true;
            this.lbl_emailCli.Location = new System.Drawing.Point(101, 403);
            this.lbl_emailCli.Name = "lbl_emailCli";
            this.lbl_emailCli.Size = new System.Drawing.Size(0, 16);
            this.lbl_emailCli.TabIndex = 14;
            // 
            // lbl_telefonoCli
            // 
            this.lbl_telefonoCli.AutoSize = true;
            this.lbl_telefonoCli.Location = new System.Drawing.Point(101, 448);
            this.lbl_telefonoCli.Name = "lbl_telefonoCli";
            this.lbl_telefonoCli.Size = new System.Drawing.Size(0, 16);
            this.lbl_telefonoCli.TabIndex = 15;
            // 
            // btn_guardar
            // 
            this.btn_guardar.Location = new System.Drawing.Point(603, 80);
            this.btn_guardar.Name = "btn_guardar";
            this.btn_guardar.Size = new System.Drawing.Size(249, 56);
            this.btn_guardar.TabIndex = 16;
            this.btn_guardar.Text = "Guardar";
            this.btn_guardar.UseVisualStyleBackColor = true;
            this.btn_guardar.Click += new System.EventHandler(this.btn_guardar_Click);
            // 
            // btn_actualizar
            // 
            this.btn_actualizar.Location = new System.Drawing.Point(603, 160);
            this.btn_actualizar.Name = "btn_actualizar";
            this.btn_actualizar.Size = new System.Drawing.Size(249, 55);
            this.btn_actualizar.TabIndex = 17;
            this.btn_actualizar.Text = "Actualizar";
            this.btn_actualizar.UseVisualStyleBackColor = true;
            this.btn_actualizar.Click += new System.EventHandler(this.btn_actualizar_Click);
            // 
            // btn_eliminar
            // 
            this.btn_eliminar.Enabled = false;
            this.btn_eliminar.Location = new System.Drawing.Point(802, 470);
            this.btn_eliminar.Name = "btn_eliminar";
            this.btn_eliminar.Size = new System.Drawing.Size(249, 56);
            this.btn_eliminar.TabIndex = 18;
            this.btn_eliminar.Text = "Eliminar";
            this.btn_eliminar.UseVisualStyleBackColor = true;
            this.btn_eliminar.Click += new System.EventHandler(this.btn_eliminar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.ClientSize = new System.Drawing.Size(1063, 528);
            this.Controls.Add(this.btn_eliminar);
            this.Controls.Add(this.btn_actualizar);
            this.Controls.Add(this.btn_guardar);
            this.Controls.Add(this.lbl_telefonoCli);
            this.Controls.Add(this.lbl_emailCli);
            this.Controls.Add(this.lbl_apellidoCli);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lbl_nombreCli);
            this.Controls.Add(this.btn_buscarCli);
            this.Controls.Add(this.txt_telefonoCliente);
            this.Controls.Add(this.txt_emailCliente);
            this.Controls.Add(this.txt_apellidoCliente);
            this.Controls.Add(this.txt_nombreCliente);
            this.Controls.Add(this.txt_idCliente);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Formulario Clientes";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_idCliente;
        private System.Windows.Forms.TextBox txt_nombreCliente;
        private System.Windows.Forms.TextBox txt_apellidoCliente;
        private System.Windows.Forms.TextBox txt_emailCliente;
        private System.Windows.Forms.TextBox txt_telefonoCliente;
        private System.Windows.Forms.Button btn_buscarCli;
        private System.Windows.Forms.Label lbl_nombreCli;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lbl_apellidoCli;
        private System.Windows.Forms.Label lbl_emailCli;
        private System.Windows.Forms.Label lbl_telefonoCli;
        private System.Windows.Forms.Button btn_guardar;
        private System.Windows.Forms.Button btn_actualizar;
        private System.Windows.Forms.Button btn_eliminar;
    }
}

